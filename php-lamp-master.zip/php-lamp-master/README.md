# LAMP Demo

To Execute this application we would be using LAMP stack.
Deploy the application code in apache server
